#pragma once

#include <cstddef>
#include <memory>
#include <utility>

/* custom memory allocator that uses a fixed-size memory arena to allocate memory. 
 * This is efficient for allocating many small objects since it minimizes fragmentation and reduces allocation overhead. */

// Class definition for a custom memory allocator that uses a fixed-size memory arena.
class ArenaAllocator {
public:
    // Constructor that initializes the allocator with a maximum number of bytes.
    explicit ArenaAllocator(const size_t max_num_bytes)
        : m_size { max_num_bytes } // Set the size of the arena.
        , m_buffer { new std::byte[max_num_bytes] } // Allocate a buffer of the specified size.
        , m_offset { m_buffer } // Initialize the offset pointer to the start of the buffer.
    {
    }

    // Delete copy constructor to prevent copying.
    ArenaAllocator(const ArenaAllocator&) = delete;

    // Delete copy assignment operator to prevent copying.
    ArenaAllocator& operator=(const ArenaAllocator&) = delete;

    // Move constructor to transfer ownership from another allocator.
    ArenaAllocator(ArenaAllocator&& other) noexcept
        : m_size { std::exchange(other.m_size, 0) } // Transfer the size.
        , m_buffer { std::exchange(other.m_buffer, nullptr) } // Transfer the buffer.
        , m_offset { std::exchange(other.m_offset, nullptr) } // Transfer the offset.
    {
    }

    // Move assignment operator to transfer ownership from another allocator.
    ArenaAllocator& operator=(ArenaAllocator&& other) noexcept
    {
        // Swap the current allocator's state with the other allocator's state.
        std::swap(m_size, other.m_size);
        std::swap(m_buffer, other.m_buffer);
        std::swap(m_offset, other.m_offset);
        return *this;
    }

    // Template function to allocate memory for an object of type T.
    template <typename T>
    [[nodiscard]] T* alloc()
    {
        // Calculate remaining bytes in the buffer.
        size_t remaining_num_bytes = m_size - static_cast<size_t>(m_offset - m_buffer);
        auto pointer = static_cast<void*>(m_offset); // Cast the offset pointer to void*.
        
        // Align the pointer to the alignment requirements of T.
        const auto aligned_address = std::align(alignof(T), sizeof(T), pointer, remaining_num_bytes);
        
        // If alignment failed, throw a bad_alloc exception.
        if (aligned_address == nullptr) {
            throw std::bad_alloc {};
        }
        
        // Move the offset pointer past the allocated memory.
        m_offset = static_cast<std::byte*>(aligned_address) + sizeof(T);
        
        // Return the aligned address cast to T*.
        return static_cast<T*>(aligned_address);
    }

    // Template function to allocate and construct an object of type T.
    template <typename T, typename... Args>
    [[nodiscard]] T* emplace(Args&&... args)
    {
        // Allocate memory for T and construct an object in the allocated memory.
        const auto allocated_memory = alloc<T>();
        return new (allocated_memory) T { std::forward<Args>(args)... };
    }

    // Destructor to clean up the allocated buffer.
    ~ArenaAllocator()
    {
        // No destructors are called for the stored objects. Thus, memory
        // leaks are possible (e.g. when storing std::vector objects or
        // other non-trivially destructible objects in the allocator).
        // Although this could be changed, it would come with additional
        // runtime overhead and therefore is not implemented.
        delete[] m_buffer; // Delete the allocated buffer.
    }

private:
    size_t m_size; // Size of the buffer.
    std::byte* m_buffer; // Pointer to the start of the buffer.
    std::byte* m_offset; // Pointer to the current offset in the buffer.
};
